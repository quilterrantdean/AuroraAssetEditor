# LCP Downloader C

Portabilidade em C puro da ferramenta de transferência de publicações a partir de ficheiros de licença LCP (`.lcpl`), optimizada para sistemas Windows XP de 32 bits.

Este projecto é uma conversão directa de um script utilitário em Python 3.4.4, redesenhado para correr de forma nativa e autónoma, com baixíssimo consumo de recursos e sem dependências de ambientes de execução pesados.

---

## Funcionalidades

*   **Análise Nativa de JSON**: Processamento rápido do ficheiro de licença `.lcpl` utilizando a biblioteca embutida `cJSON`.
*   **Arquitectura de Streaming para Arquivos ZIP**: Injecção da licença directamente no ficheiro descarregado utilizando a biblioteca `miniz` com operações de leitura/escrita em streaming de baixo nível (Win32). Consumo de memória insignificante (escala de kilobytes), suportando de forma segura ficheiros muito maiores que a RAM disponível (ex: Audiobooks de vários gigabytes).
*   **Suporte Total a Unicode**: Compatível com caminhos de ficheiros que contenham acentos ou caracteres especiais no Windows XP, recorrendo a APIs nativas de caracteres largos (`wchar_t`).
*   **Mapeamento Automático de Extensões**: Atribuição da extensão correcta ao ficheiro de saída com base na especificação LCP (`.epub`, `.lcpdf`, `.lcpa`, `.webpub`, `.audiobook`).
*   **Transferência Segura**: Utilização do utilitário externo `wget.exe` para contornar as limitações de TLS 1.2/1.3 nativas do Windows XP ao aceder a servidores modernos de livros digitais via HTTPS.

---

## Estrutura do Directório do Projecto

```text
lcp-downloader/
├── bin/
│   └── wget.exe              # Utilitário wget compatível com Windows XP (necessário no destino)
├── src/
│   ├── cjson/
│   │   ├── cJSON.c
│   │   └── cJSON.h
│   ├── miniz/
│   │   ├── miniz.c
│   │   └── miniz.h
│   ├── config.h
│   ├── utils.h
│   ├── utils.c
│   ├── downloader.h
│   ├── downloader.c
│   ├── lcpl_parser.h
│   ├── lcpl_parser.c
│   ├── injector.h
│   ├── injector.c
│   └── main.c
└── README.md
```

---

## Pré-requisitos

Para preparar o ambiente de compilação e execução no Windows XP:

1.  **Compilador**: TDM-GCC-32 ou MinGW32 instalado e acessível pela linha de comandos.
2.  **wget.exe**: Descarregue a versão de 32 bits compatível com Windows XP (por exemplo, a partir do arquivo em [eternallybored.org](https://eternallybored.org/misc/wget/)) e coloque-a na directoria `bin/` ou configure o caminho no ficheiro `src/config.h`.
3.  **Bibliotecas de Terceiros** (Código-fonte incluído na directoria `src/`):
    *   [cJSON](https://github.com/DaveGamble/cJSON) (domínio público) para análise sintáctica de JSON.
    *   [miniz](https://github.com/richgel999/miniz) para manipulação de ficheiros comprimidos ZIP.

---

## Instruções de Compilação

Abra a linha de comandos do Windows (`cmd.exe`), navegue até à pasta raiz do projecto e execute o compilador GCC com a flag de optimização e desactivação de funções desnecessárias de StdIO da biblioteca `miniz` (isto evita incompatibilidades com a MSVCRT antiga do Windows XP):

```cmd
gcc -O2 -Wall -DMINIZ_NO_STDIO -o bin\lcp_downloader.exe src\main.c src\utils.c src\lcpl_parser.c src\downloader.c src\injector.c src\cjson\cJSON.c src\miniz\miniz.c -lshlwapi -lshell32
```

---

## Como Utilizar

O executável gerado suporta a passagem de parâmetros pela consola e interacção directa por interface gráfica no Windows Explorer.

### Uso Básico (Duplo-clique ou Arrastar)
*   **Duplo-clique**: Se associar a extensão `.lcpl` a este programa, basta fazer duplo-clique no ficheiro de licença para iniciar o processamento automático.
*   **Drag & Drop**: Pode arrastar qualquer ficheiro `.lcpl` e largá-lo por cima do executável `lcp_downloader.exe` para iniciar a transferência.

### Uso por Linha de Comandos
```cmd
lcp_downloader.exe [opções] [FICHEIRO.lcpl]
```

### Opções Disponíveis:
*   `-k, --manter-lcpl` : Mantém o ficheiro `.lcpl` original no disco após a conclusão do processo.
*   `-a, --apagar-lcpl` : Apaga o ficheiro `.lcpl` original do disco após injectar a licença no livro (comportamento predefinido).
*   `-n, --nao-injetar` : Limita-se a descarregar o livro original sem realizar a injecção da licença de leitura.
*   `-i, --injetar`     : Descarrega o livro e embute o ficheiro `.lcpl` (comportamento predefinido).
*   `-v, --versao`      : Exibe a versão actual da aplicação.
*   `-h, --help`        : Apresenta o menu de ajuda com a lista de comandos.

### Exemplos:
```cmd
# Descarrega e injeta a licença, apagando o .lcpl no final
lcp_downloader.exe livro.lcpl

# Descarrega e mantem o ficheiro .lcpl intacto no directório
lcp_downloader.exe -k livro.lcpl

# Apenas descarrega o ficheiro bruto (sem alteração do arquivo ZIP)
lcp_downloader.exe -n livro.lcpl
```

---

## Isenção de Responsabilidade

Este software destina-se exclusivamente a facilitar o acesso a livros legitimamente adquiridos por utilizadores em plataformas compatíveis com a tecnologia LCP, permitindo a interoperabilidade em sistemas operativos antigos que já não possuem suporte oficial por parte dos leitores modernos. O projecto não contorna mecanismos de encriptação nem quebra a segurança das chaves de leitura DRM.