#include "utils.h"
#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <shlwapi.h>

/* Necessário ligar com a biblioteca Shlwapi.lib no Dev-C++ / GCC (-lshlwapi) */

BOOL ficheiro_existe(const wchar_t *caminho) {
    DWORD atributos = GetFileAttributesW(caminho);
    return (atributos != INVALID_FILE_ATTRIBUTES && !(atributos & FILE_ATTRIBUTE_DIRECTORY));
}

BOOL obter_directorio_executavel(wchar_t *buffer, DWORD tamanho) {
    DWORD resultado = GetModuleFileNameW(NULL, buffer, tamanho);
    if (resultado == 0 || resultado == tamanho) {
        return FALSE;
    }
    /* Remove o nome do executável, mantendo apenas o directório */
    PathRemoveFileSpecW(buffer);
    return TRUE;
}

BOOL obter_caminho_wget(wchar_t *buffer, DWORD tamanho) {
    wchar_t dir_exe[MAX_PATH];
    
    if (obter_directorio_executavel(dir_exe, MAX_PATH)) {
        /* Tenta localizar o wget.exe no mesmo directório do programa */
        _snwprintf(buffer, tamanho, L"%s\\wget.exe", dir_exe);
        if (ficheiro_existe(buffer)) {
            return TRUE;
        }
    }
    
    /* Se não existir no directório local, tenta o caminho predefinido de sistema */
    if (ficheiro_existe(WGET_FALLBACK_PATH)) {
        wcsncpy(buffer, WGET_FALLBACK_PATH, tamanho);
        buffer[tamanho - 1] = L'\0';
        return TRUE;
    }
    
    return FALSE;
}

wchar_t *converter_utf8_para_utf16(const char *origem) {
    int tamanho_necessario;
    wchar_t *destino;

    if (!origem) return NULL;

    tamanho_necessario = MultiByteToWideChar(CP_UTF8, 0, origem, -1, NULL, 0);
    if (tamanho_necessario == 0) return NULL;

    destino = (wchar_t *)malloc(tamanho_necessario * sizeof(wchar_t));
    if (!destino) return NULL;

    MultiByteToWideChar(CP_UTF8, 0, origem, -1, destino, tamanho_necessario);
    return destino;
}

char *converter_utf16_para_utf8(const wchar_t *origem) {
    int tamanho_necessario;
    char *destino;

    if (!origem) return NULL;

    tamanho_necessario = WideCharToMultiByte(CP_UTF8, 0, origem, -1, NULL, 0, NULL, NULL);
    if (tamanho_necessario == 0) return NULL;

    destino = (char *)malloc(tamanho_necessario * sizeof(char));
    if (!destino) return NULL;

    WideCharToMultiByte(CP_UTF8, 0, origem, -1, destino, tamanho_necessario, NULL, NULL);
    return destino;
}

void url_decode(char *destino, const char *origem) {
    while (*origem) {
        if (*origem == '%' && *(origem + 1) && *(origem + 2)) {
            char hex[3];
            hex[0] = *(origem + 1);
            hex[1] = *(origem + 2);
            hex[2] = '\0';
            *destino = (char)strtol(hex, NULL, 16);
            origem += 3;
        } else if (*origem == '+') {
            *destino = ' ';
            origem++;
        } else {
            *destino = *origem;
            origem++;
        }
        destino++;
    }
    *destino = '\0';
}

void sanitizar_nome_ficheiro(wchar_t *nome) {
    const wchar_t *invalidos = L"<>:\"/\\|?*";
    wchar_t *p = nome;
    
    while (*p) {
        if (wcschr(invalidos, *p)) {
            *p = L'_';
        }
        p++;
    }
    
    /* Remove pontos e espaços no início ou fim (limitação do Windows) */
    p = nome;
    while (*p == L' ' || *p == L'.') {
        *p = L'_';
        p++;
    }
    
    size_t len = wcslen(nome);
    while (len > 0 && (nome[len - 1] == L' ' || nome[len - 1] == L'.')) {
        nome[len - 1] = L'_';
        len--;
    }
}