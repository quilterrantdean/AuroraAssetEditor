#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>

#include "config.h"
#include "utils.h"
#include "lcpl_parser.h"
#include "downloader.h"
#include "injector.h"

/* Exibe a ajuda do programa */
static void mostrar_ajuda(const wchar_t *prog_nome) {
    wprintf(L"LCP Downloader %hs\n\n", LCP_DOWNLOADER_VERSION);
    wprintf(L"Descarrega ebooks a partir de ficheiros LCP License (.lcpl).\n\n");
    wprintf(L"Uso:\n");
    wprintf(L"  %s [opcoes] [FICHEIRO.lcpl]\n\n", prog_nome);
    wprintf(L"Opcoes:\n");
    wprintf(L"  -k, --manter-lcpl   Mantem o ficheiro .lcpl original apos a injeccao.\n");
    wprintf(L"  -a, --apagar-lcpl   Apaga o ficheiro .lcpl original apos a injeccao.\n");
    wprintf(L"  -n, --nao-injetar   So descarrega o ficheiro; NAO insere a licenca.\n");
    wprintf(L"  -i, --injetar       Descarrega e injeta a licenca (comportamento padrao).\n");
    wprintf(L"  -v, --versao        Mostra a versao do programa.\n");
    wprintf(L"  -h, --help          Mostra esta ajuda.\n\n");
    wprintf(L"DICA: Pode arrastar um ficheiro .lcpl para cima deste executavel.\n");
}

/* Processa um ficheiro .lcpl individual */
static int processar_lcpl(const wchar_t *caminho_lcpl, int manter_lcpl, int nao_injetar) {
    DadosLCPL dados;
    wchar_t *caminho_ebook = NULL;
    int sucesso = 0;

    if (!ficheiro_existe(caminho_lcpl)) {
        wprintf(L"ERRO: Ficheiro nao encontrado: %s\n", caminho_lcpl);
        return 0;
    }

    wprintf(L"LCP Downloader %hs\n\nA processar: %s\n\n", LCP_DOWNLOADER_VERSION, caminho_lcpl);

    /* 1. Ler dados do ficheiro LCPL */
    if (!ler_lcpl(caminho_lcpl, &dados)) {
        wprintf(L"ERRO: Falha ao analisar o ficheiro .lcpl.\n");
        return 0;
    }

    wprintf(L"URL encontrado: %hs\n", dados.url);
    wprintf(L"Tipo MIME: %hs\n", dados.mime_type ? dados.mime_type : "desconhecido");

    /* 2. Descarregar o eBook */
    caminho_ebook = descarregar_ebook(dados.url, dados.mime_type, dados.id_licenca, caminho_lcpl);
    if (!caminho_ebook) {
        wprintf(L"ERRO: Falha ao descarregar o ebook.\n");
        libertar_dados_lcpl(&dados);
        return 0;
    }

    /* 3. Injectar a licença (se aplicável) */
    if (!nao_injetar) {
        if (injetar_licenca(caminho_ebook, caminho_lcpl)) {
            sucesso = 1;
            /* 4. Apagar o .lcpl original (se solicitado) */
            if (!manter_lcpl) {
                if (DeleteFileW(caminho_lcpl)) {
                    wprintf(L"Ficheiro original .lcpl apagado do disco.\n");
                } else {
                    wprintf(L"Aviso: Nao foi possivel apagar o ficheiro .lcpl original.\n");
                }
            }
        } else {
            wprintf(L"ERRO: O download foi concluido, mas a injeccao da licenca falhou.\n");
        }
    } else {
        wprintf(L"Injeccao ignorada (modo nao-injetar activo). O ficheiro mantem-se bruto.\n");
        sucesso = 1;
    }

    if (sucesso) {
        wprintf(L"\nConcluido com sucesso! Ficheiro final: %s\n", caminho_ebook);
    }

    free(caminho_ebook);
    libertar_dados_lcpl(&dados);
    return sucesso;
}

int main(void) {
    int argc_w;
    wchar_t **argv_w;
    wchar_t *ficheiro_target = NULL;
    
    int manter_lcpl = DEFAULT_MANTER_LCPL;
    int nao_injetar = DEFAULT_NAO_INJETAR;
    int i;
    int resultado = 0;

    /* Configura o suporte a caracteres locais na consola do Windows */
    setlocale(LC_ALL, "");

    /* Obtém argumentos da linha de comandos em formato Unicode (UTF-16) */
    argv_w = CommandLineToArgvW(GetCommandLineW(), &argc_w);
    if (!argv_w) {
        wprintf(L"ERRO: Falha ao inicializar argumentos da linha de comandos.\n");
        return 1;
    }

    /* Processar argumentos (parsing manual simples e robusto) */
    for (i = 1; i < argc_w; i++) {
        if (wcscmp(argv_w[i], L"-k") == 0 || wcscmp(argv_w[i], L"--manter-lcpl") == 0) {
            manter_lcpl = 1;
        } else if (wcscmp(argv_w[i], L"-a") == 0 || wcscmp(argv_w[i], L"--apagar-lcpl") == 0) {
            manter_lcpl = 0;
        } else if (wcscmp(argv_w[i], L"-n") == 0 || wcscmp(argv_w[i], L"--nao-injetar") == 0) {
            nao_injetar = 1;
        } else if (wcscmp(argv_w[i], L"-i") == 0 || wcscmp(argv_w[i], L"--injetar") == 0) {
            nao_injetar = 0;
        } else if (wcscmp(argv_w[i], L"-v") == 0 || wcscmp(argv_w[i], L"--versao") == 0) {
            wprintf(L"LCP Downloader versao %hs\n", LCP_DOWNLOADER_VERSION);
            LocalFree(argv_w);
            return 0;
        } else if (wcscmp(argv_w[i], L"-h") == 0 || wcscmp(argv_w[i], L"--help") == 0 || wcscmp(argv_w[i], L"-?") == 0) {
            mostrar_ajuda(argv_w[0]);
            LocalFree(argv_w);
            return 0;
        } else if (argv_w[i][0] == L'-') {
            wprintf(L"Opcao desconhecida: %s\n", argv_w[i]);
            mostrar_ajuda(argv_w[0]);
            LocalFree(argv_w);
            return 1;
        } else {
            /* Assume-se que o argumento posicional seja o ficheiro .lcpl */
            ficheiro_target = argv_w[i];
        }
    }

    if (!ficheiro_target) {
        mostrar_ajuda(argv_w[0]);
        wprintf(L"\nDICA: Pode fazer duplo-clique num ficheiro .lcpl ou arrasta-lo para aqui.\n");
        
        /* Impede o encerramento imediato da consola no caso de duplo-clique */
        wprintf(L"\nPrima Enter para sair...");
        getchar();
        
        LocalFree(argv_w);
        return 0;
    }

    resultado = processar_lcpl(ficheiro_target, manter_lcpl, nao_injetar);

    LocalFree(argv_w);
    
    if (!resultado) {
        wprintf(L"\nFalha no processamento.\n");
        wprintf(L"Prima Enter para fechar...");
        getchar();
        return 1;
    }

    return 0;
}