#ifndef CONFIG_H
#define CONFIG_H

#define LCP_DOWNLOADER_VERSION "1.0.3"

/* Configurações predefinidas (comportamento por omissão do duplo-clique) */
#define DEFAULT_MANTER_LCPL 0  /* 0 = apaga o .lcpl após injecção, 1 = mantém */
#define DEFAULT_NAO_INJETAR 0  /* 0 = injeta a licença, 1 = apenas descarrega */

/* Caminho alternativo global se o wget não for encontrado junto ao executável */
#define WGET_FALLBACK_PATH L"C:\\Program Files\\wget\\wget.exe"

#endif /* CONFIG_H */