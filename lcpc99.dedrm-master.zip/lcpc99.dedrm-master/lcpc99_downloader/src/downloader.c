#include "downloader.h"
#include "utils.h"
#include "lcpl_parser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <shlwapi.h>

/* Função interna para obter o tamanho de um ficheiro */
static DWORD obter_tamanho_ficheiro(const wchar_t *caminho) {
    WIN32_FILE_ATTRIBUTE_DATA dados;
    if (GetFileAttributesExW(caminho, GetFileExInfoStandard, &dados)) {
        return dados.nFileSizeLow;
    }
    return 0;
}

wchar_t *descarregar_ebook(const char *url, const char *mime_type, const char *id_licenca, const wchar_t *caminho_lcpl) {
    wchar_t caminho_wget[MAX_PATH];
    wchar_t dir_destino[MAX_PATH];
    wchar_t nome_ficheiro_w[MAX_PATH];
    wchar_t *caminho_final = NULL;
    size_t tamanho_caminho_final;
    
    char *nome_base_url = NULL;
    char *temp_decode = NULL;
    const char *barra = NULL;
    const char *p = NULL;
    
    /* 1. Verificar se o wget.exe está disponível */
    if (!obter_caminho_wget(caminho_wget, MAX_PATH)) {
        wprintf(L"ERRO: wget.exe n\u00e3o encontrado no direct\u00f3rio local nem em C:\\Program Files\\wget\\wget.exe\n");
        return NULL;
    }

    /* 2. Extrair o nome do ficheiro do URL */
    barra = strrchr(url, '/');
    if (barra) {
        nome_base_url = strdup(barra + 1);
    } else {
        nome_base_url = strdup(url);
    }

    /* Cortar parâmetros de consulta (?...) ou fragmentos (#...) */
    p = strchr(nome_base_url, '?');
    if (p) nome_base_url[p - url] = '\0'; /* Ajuste do ponteiro */
    p = strchr(nome_base_url, '#');
    if (p) nome_base_url[p - url] = '\0';

    /* Descodificar URL (ex: %20 -> espaço) */
    temp_decode = (char *)malloc(strlen(nome_base_url) + 1);
    if (temp_decode) {
        url_decode(temp_decode, nome_base_url);
        free(nome_base_url);
        nome_base_url = temp_decode;
    }

    /* Converter para wchar_t (Unicode) */
    wchar_t *convertido = converter_utf8_para_utf16(nome_base_url);
    if (convertido) {
        wcsncpy(nome_ficheiro_w, convertido, MAX_PATH);
        nome_ficheiro_w[MAX_PATH - 1] = L'\0';
        free(convertido);
    } else {
        nome_ficheiro_w[0] = L'\0';
    }
    free(nome_base_url);

    /* Sanitizar caracteres ilegais no Windows */
    sanitizar_nome_ficheiro(nome_ficheiro_w);

    /* Se o nome ficou vazio, usa o ID da licença */
    if (wcslen(nome_ficheiro_w) == 0) {
        wchar_t *id_w = converter_utf8_para_utf16(id_licenca);
        if (id_w) {
            wcsncpy(nome_ficheiro_w, id_w, MAX_PATH);
            nome_ficheiro_w[MAX_PATH - 1] = L'\0';
            free(id_w);
        } else {
            wcsncpy(nome_ficheiro_w, L"ebook", MAX_PATH);
        }
    }

    /* Remover a extensão original (se existir) para aplicar a correcta segundo o tipo MIME */
    PathRemoveExtensionW(nome_ficheiro_w);
    wcscat(nome_ficheiro_w, obter_extensao_por_tipo(mime_type));

    /* 3. Definir o caminho de destino no mesmo directório do .lcpl */
    wcsncpy(dir_destino, caminho_lcpl, MAX_PATH);
    dir_destino[MAX_PATH - 1] = L'\0';
    PathRemoveFileSpecW(dir_destino);

    tamanho_caminho_final = wcslen(dir_destino) + wcslen(nome_ficheiro_w) + 2;
    caminho_final = (wchar_t *)malloc(tamanho_caminho_final * sizeof(wchar_t));
    if (!caminho_final) return NULL;

    _snwprintf(caminho_final, tamanho_caminho_final, L"%s\\%s", dir_destino, nome_ficheiro_w);

    /* 4. Preparar os argumentos e lançar o wget */
    {
        wchar_t *url_w = converter_utf8_para_utf16(url);
        wchar_t comando[32768];
        STARTUPINFOW si;
        PROCESS_INFORMATION pi;
        BOOL criado = FALSE;

        memset(&si, 0, sizeof(si));
        si.cb = sizeof(si);
        memset(&pi, 0, sizeof(pi));

        /* Montar linha de comandos robusta com aspas para proteger caminhos com espaços */
        _snwprintf(comando, 32768, L"\"%s\" --no-check-certificate -O \"%s\" \"%s\"", 
                   caminho_wget, caminho_final, url_w);
        free(url_w);

        wprintf(L"A descarregar o ficheiro...\n");
        wprintf(L"A guardar como: %s\n", nome_ficheiro_w);

        /* Executa o processo de forma limpa */
        criado = CreateProcessW(
            NULL,            /* Executável (passado na linha de comandos) */
            comando,         /* Linha de comandos editável */
            NULL, NULL,      /* Atributos de segurança */
            FALSE,           /* Não herda handles */
            0,               /* Flags de criação */
            NULL,            /* Ambiente */
            NULL,            /* Directório de trabalho */
            &si, &pi
        );

        if (!criado) {
            wprintf(L"ERRO: Falha ao iniciar o processo do wget (Erro Windows: %lu).\n", GetLastError());
            free(caminho_final);
            return NULL;
        }

        /* Esperar que a transferência termine */
        WaitForSingleObject(pi.hProcess, INFINITE);
        
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }

    /* 5. Verificar o sucesso da transferência (se o ficheiro existe e não está vazio) */
    if (!ficheiro_existe(caminho_final) || obter_tamanho_ficheiro(caminho_final) == 0) {
        wprintf(L"ERRO: O ficheiro n\u00e3o foi descarregado ou est\u00e1 vazio.\n");
        free(caminho_final);
        return NULL;
    }

    return caminho_final;
}