#include "lcpl_parser.h"
#include "cjson/cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *duplicar_string(const char *s) {
    if (!s) return NULL;
    size_t len = strlen(s) + 1;
    char *d = (char *)malloc(len);
    if (d) memcpy(d, s, len);
    return d;
}

const wchar_t *obter_extensao_por_tipo(const char *mime_type) {
    if (!mime_type) {
        return L".epub"; /* Fallback por omissão */
    }

    /* Correspondência exacta */
    if (stricmp(mime_type, "application/epub+zip") == 0)      return L".epub";
    if (stricmp(mime_type, "application/pdf+lcp") == 0)       return L".lcpdf";
    if (stricmp(mime_type, "application/audiobook+lcp") == 0) return L".lcpa";
    if (stricmp(mime_type, "application/audiobook+zip") == 0) return L".audiobook";
    if (stricmp(mime_type, "application/webpub+zip") == 0)    return L".webpub";
    if (stricmp(mime_type, "application/lpf+zip") == 0)       return L".webpub";

    /* Procura por substring caso o servidor utilize variantes não normalizadas */
    if (strstr(mime_type, "epub"))      return L".epub";
    if (strstr(mime_type, "pdf"))       return L".lcpdf";
    if (strstr(mime_type, "audiobook")) return L".lcpa";
    if (strstr(mime_type, "webpub"))    return L".webpub";
    if (strstr(mime_type, "lpf"))       return L".webpub";

    return L".epub";
}

int ler_lcpl(const wchar_t *caminho_lcpl, DadosLCPL *resultado) {
    FILE *f = NULL;
    long tamanho_ficheiro = 0;
    char *buffer = NULL;
    char *dados_json = NULL;
    cJSON *json = NULL;
    cJSON *id_obj = NULL;
    cJSON *links_obj = NULL;
    int sucesso = 0;

    if (!resultado) return 0;
    memset(resultado, 0, sizeof(DadosLCPL));

    /* Abre o ficheiro usando a API Unicode do Windows XP (msvcrt.dll) */
    f = _wfopen(caminho_lcpl, L"rb");
    if (!f) {
        wprintf(L"ERRO: N\u00e3o foi poss\u00edvel abrir o ficheiro LCPL.\n");
        return 0;
    }

    /* Determina o tamanho do ficheiro */
    fseek(f, 0, SEEK_END);
    tamanho_ficheiro = ftell(f);
    fseek(f, 0, SEEK_SET);

    buffer = (char *)malloc(tamanho_ficheiro + 1);
    if (!buffer) {
        fclose(f);
        return 0;
    }

    if (fread(buffer, 1, tamanho_ficheiro, f) != (size_t)tamanho_ficheiro) {
        free(buffer);
        fclose(f);
        return 0;
    }
    buffer[tamanho_ficheiro] = '\0';
    fclose(f);

    /* Trata o marcador de ordem de byte (BOM) UTF-8 se estiver presente */
    dados_json = buffer;
    if (tamanho_ficheiro >= 3 && 
        (unsigned char)buffer[0] == 0xEF && 
        (unsigned char)buffer[1] == 0xBB && 
        (unsigned char)buffer[2] == 0xBF) {
        dados_json = buffer + 3;
    }

    json = cJSON_Parse(dados_json);
    if (!json) {
        printf("ERRO: Erro de sintaxe JSON no ficheiro LCPL.\n");
        free(buffer);
        return 0;
    }

    /* Extrai o ID da licença */
    id_obj = cJSON_GetObjectItemCaseSensitive(json, "id");
    if (cJSON_IsString(id_obj) && (id_obj->valuestring != NULL)) {
        resultado->id_licenca = duplicar_string(id_obj->valuestring);
    } else {
        resultado->id_licenca = duplicar_string("ebook_desconhecido");
    }

    /* Procura o link de publicação ("rel": "publication") */
    links_obj = cJSON_GetObjectItemCaseSensitive(json, "links");
    if (cJSON_IsArray(links_obj)) {
        int i;
        int num_elementos = cJSON_GetArraySize(links_obj);
        for (i = 0; i < num_elementos; i++) {
            cJSON *link = cJSON_GetArrayItem(links_obj, i);
            cJSON *rel_obj = cJSON_GetObjectItemCaseSensitive(link, "rel");
            
            if (cJSON_IsString(rel_obj) && strcmp(rel_obj->valuestring, "publication") == 0) {
                cJSON *href_obj = cJSON_GetObjectItemCaseSensitive(link, "href");
                cJSON *type_obj = cJSON_GetObjectItemCaseSensitive(link, "type");

                if (cJSON_IsString(href_obj) && (href_obj->valuestring != NULL)) {
                    resultado->url = duplicar_string(href_obj->valuestring);
                }
                if (cJSON_IsString(type_obj) && (type_obj->valuestring != NULL)) {
                    resultado->mime_type = duplicar_string(type_obj->valuestring);
                }
                sucesso = 1;
                break;
            }
        }
    }

    cJSON_Delete(json);
    free(buffer);

    if (sucesso && !resultado->url) {
        /* Encontrou a relação mas falta o URL */
        sucesso = 0;
    }

    if (!sucesso) {
        libertar_dados_lcpl(resultado);
    }

    return sucesso;
}

void libertar_dados_lcpl(DadosLCPL *dados) {
    if (dados) {
        if (dados->url) {
            free(dados->url);
            dados->url = NULL;
        }
        if (dados->mime_type) {
            free(dados->mime_type);
            dados->mime_type = NULL;
        }
        if (dados->id_licenca) {
            free(dados->id_licenca);
            dados->id_licenca = NULL;
        }
    }
}