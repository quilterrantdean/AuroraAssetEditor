#ifndef INJECTOR_H
#define INJECTOR_H

#include <wchar.h>

/* Injecta o ficheiro .lcpl dentro do arquivo do ebook (EPUB, PDF, etc.).
   Retorna 1 em caso de sucesso, 0 em caso de falha. */
int injetar_licenca(const wchar_t *caminho_ebook, const wchar_t *caminho_lcpl);

#endif /* INJECTOR_H */