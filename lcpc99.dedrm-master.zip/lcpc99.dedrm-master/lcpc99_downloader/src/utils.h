#ifndef UTILS_H
#define UTILS_H

#include <wchar.h>
#include <windows.h>

/* Verifica se um ficheiro existe no caminho indicado */
BOOL ficheiro_existe(const wchar_t *caminho);

/* Obtém o directório onde o executável do programa está alojado */
BOOL obter_directorio_executavel(wchar_t *buffer, DWORD tamanho);

/* Determina o caminho correcto para o wget.exe (relativo ou absoluto) */
BOOL obter_caminho_wget(wchar_t *buffer, DWORD tamanho);

/* Converte uma string UTF-8 para UTF-16 (usada pelas APIs do Windows) */
wchar_t *converter_utf8_para_utf16(const char *origem);

/* Converte uma string UTF-16 para UTF-8 */
char *converter_utf16_para_utf8(const wchar_t *origem);

/* Descodifica sequências %XX de um URL (URL-decode) */
void url_decode(char *destino, const char *origem);

/* Substitui caracteres inválidos do Windows num nome de ficheiro por sublinhados */
void sanitizar_nome_ficheiro(wchar_t *nome);

#endif /* UTILS_H */