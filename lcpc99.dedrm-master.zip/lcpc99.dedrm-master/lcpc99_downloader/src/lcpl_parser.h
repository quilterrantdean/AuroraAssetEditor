#ifndef LCPL_PARSER_H
#define LCPL_PARSER_H

#include <wchar.h>

typedef struct {
    char *url;         /* URL de publicação (UTF-8, alocado dinamicamente) */
    char *mime_type;   /* Tipo MIME (UTF-8, alocado dinamicamente) */
    char *id_licenca;  /* ID da licença (UTF-8, alocado dinamicamente) */
} DadosLCPL;

/* Lê e analisa o ficheiro .lcpl. Retorna 1 em caso de sucesso, 0 em caso de falha. */
int ler_lcpl(const wchar_t *caminho_lcpl, DadosLCPL *resultado);

/* Liberta a memória alocada na estrutura de dados */
void libertar_dados_lcpl(DadosLCPL *dados);

/* Mapeia o tipo MIME para a extensão de ficheiro correspondente */
const wchar_t *obter_extensao_por_tipo(const char *mime_type);

#endif /* LCPL_PARSER_H */