#include "injector.h"
#include "miniz/miniz.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Função de leitura personalizada para o miniz (Directo do Disco via API Win32) */
static size_t win32_zip_read_callback(void *pOpaque, mz_uint64 file_ofs, void *pBuf, size_t n) {
    HANDLE hFile = (HANDLE)pOpaque;
    LARGE_INTEGER li;
    DWORD lidos = 0;

    li.QuadPart = file_ofs;
    if (!SetFilePointerEx(hFile, li, NULL, FILE_BEGIN)) {
        return 0;
    }

    if (!ReadFile(hFile, pBuf, (DWORD)n, &lidos, NULL)) {
        return 0;
    }

    return (size_t)lidos;
}

/* Função de escrita personalizada para o miniz (Directo para o Disco via API Win32) */
static size_t win32_zip_write_callback(void *pOpaque, mz_uint64 file_ofs, const void *pBuf, size_t n) {
    HANDLE hFile = (HANDLE)pOpaque;
    LARGE_INTEGER li;
    DWORD escritos = 0;

    li.QuadPart = file_ofs;
    if (!SetFilePointerEx(hFile, li, NULL, FILE_BEGIN)) {
        return 0;
    }

    if (!WriteFile(hFile, pBuf, (DWORD)n, &escritos, NULL)) {
        return 0;
    }

    return (size_t)escritos;
}

/* Função auxiliar para ler apenas a licença .lcpl para a memória */
static void *ler_licenca_completa(const wchar_t *caminho, DWORD *tamanho_saida) {
    HANDLE hFile = CreateFileW(caminho, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return NULL;

    DWORD tamanho = GetFileSize(hFile, NULL);
    if (tamanho == INVALID_FILE_SIZE || tamanho == 0) {
        CloseHandle(hFile);
        return NULL;
    }

    void *buffer = malloc(tamanho);
    if (!buffer) {
        CloseHandle(hFile);
        return NULL;
    }

    DWORD lidos;
    if (!ReadFile(hFile, buffer, tamanho, &lidos, NULL) || lidos != tamanho) {
        free(buffer);
        CloseHandle(hFile);
        return NULL;
    }

    CloseHandle(hFile);
    *tamanho_saida = tamanho;
    return buffer;
}

int injetar_licenca(const wchar_t *caminho_ebook, const wchar_t *caminho_lcpl) {
    HANDLE hSource = INVALID_HANDLE_VALUE;
    HANDLE hTemp = INVALID_HANDLE_VALUE;
    void *lcpl_data = NULL;
    DWORD lcpl_tamanho = 0;
    LARGE_INTEGER liSize;
    
    mz_zip_archive reader_zip;
    mz_zip_archive writer_zip;
    int sucesso = 0;
    const char *destino_interno = "license.lcpl";
    wchar_t caminho_temp[MAX_PATH];

    /* 1. Determinar o destino interno baseado na extensão do ficheiro */
    size_t len = wcslen(caminho_ebook);
    if (len > 5 && _wcsicmp(caminho_ebook + len - 5, L".epub") == 0) {
        destino_interno = "META-INF/license.lcpl";
    }

    /* 2. Carregar o pequeno ficheiro de licença .lcpl para a memória */
    lcpl_data = ler_licenca_completa(caminho_lcpl, &lcpl_tamanho);
    if (!lcpl_data) {
        wprintf(L"ERRO: N\u00e3o foi poss\u00edvel ler o ficheiro .lcpl.\n");
        return 0;
    }

    /* 3. Abrir o ficheiro original do ebook para leitura */
    hSource = CreateFileW(caminho_ebook, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hSource == INVALID_HANDLE_VALUE) {
        wprintf(L"ERRO: N\u00e3o foi poss\u00edvel abrir o ebook para leitura.\n");
        free(lcpl_data);
        return 0;
    }

    /* Obter tamanho do ficheiro original */
    if (!GetFileSizeEx(hSource, &liSize)) {
        wprintf(L"ERRO: N\u00e3o foi poss\u00edvel obter o tamanho do ebook.\n");
        CloseHandle(hSource);
        free(lcpl_data);
        return 0;
    }

    /* 4. Configurar e inicializar o leitor ZIP com o callback personalizado */
    memset(&reader_zip, 0, sizeof(reader_zip));
    reader_zip.m_pRead = win32_zip_read_callback;
    reader_zip.m_pIO_opaque = hSource;

    if (!mz_zip_reader_init(&reader_zip, liSize.QuadPart, 0)) {
        wprintf(L"ERRO: O ficheiro descarregado n\u00e3o parece ser um arquivo ZIP v\u00e1lido.\n");
        CloseHandle(hSource);
        free(lcpl_data);
        return 0;
    }

    /* 5. Verificar se a licença já existe dentro do arquivo */
    if (mz_zip_reader_locate_file(&reader_zip, destino_interno, NULL, 0) >= 0) {
        wprintf(L"Aviso: O arquivo j\u00e1 cont\u00e9m \"%hs\"; entrada existente mantida.\n", destino_interno);
        mz_zip_reader_end(&reader_zip);
        CloseHandle(hSource);
        free(lcpl_data);
        return 1; /* Sucesso */
    }

    /* 6. Criar o ficheiro temporário para o novo ZIP em disco */
    _snwprintf(caminho_temp, MAX_PATH, L"%s.tmp", caminho_ebook);
    hTemp = CreateFileW(caminho_temp, GENERIC_WRITE | GENERIC_READ, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hTemp == INVALID_HANDLE_VALUE) {
        wprintf(L"ERRO: N\u00e3o foi poss\u00edvel criar o ficheiro tempor\u00e1rio no disco.\n");
        mz_zip_reader_end(&reader_zip);
        CloseHandle(hSource);
        free(lcpl_data);
        return 0;
    }

    /* 7. Configurar e inicializar o construtor ZIP no canal temporário com o callback */
    memset(&writer_zip, 0, sizeof(writer_zip));
    writer_zip.m_pWrite = win32_zip_write_callback;
    writer_zip.m_pIO_opaque = hTemp;

    /* mz_zip_writer_init_v2 recebe apenas 3 argumentos nesta versão da biblioteca */
    if (!mz_zip_writer_init_v2(&writer_zip, 0, 0)) {
        wprintf(L"ERRO: Falha ao inicializar o construtor ZIP no disco.\n");
        goto limpar;
    }

    /* 8. Copiar todas as entradas do arquivo antigo para o novo */
    wprintf(L"A processar o arquivo ZIP em streaming...\n");
    mz_uint num_ficheiros = mz_zip_reader_get_num_files(&reader_zip);
    mz_uint i;
    for (i = 0; i < num_ficheiros; i++) {
        if (!mz_zip_writer_add_from_zip_reader(&writer_zip, &reader_zip, i)) {
            wprintf(L"ERRO: Falha ao copiar dados internos do arquivo.\n");
            goto limpar;
        }
    }

    /* 9. Adicionar o ficheiro da licença sem compressão (Stored) */
    wprintf(L"A injectar a licen\u00e7a no ficheiro descarregado (%hs)...\n", destino_interno);
    if (!mz_zip_writer_add_mem(&writer_zip, destino_interno, lcpl_data, lcpl_tamanho, MZ_NO_COMPRESSION)) {
        wprintf(L"ERRO: Falha ao adicionar a licen\u00e7a ao arquivo.\n");
        goto limpar;
    }

    /* 10. Finalizar e fechar os arquivos ZIP */
    if (!mz_zip_writer_finalize_archive(&writer_zip)) {
        wprintf(L"ERRO: Falha ao finalizar o arquivo ZIP no disco.\n");
        goto limpar;
    }

    sucesso = 1;

limpar:
    mz_zip_reader_end(&reader_zip);
    mz_zip_writer_end(&writer_zip);
    
    CloseHandle(hSource);
    CloseHandle(hTemp);
    free(lcpl_data);

    /* 11. Substituição segura dos ficheiros no disco */
    if (sucesso) {
        if (!DeleteFileW(caminho_ebook)) {
            wprintf(L"ERRO: N\u00e3o foi poss\u00edvel substituir o ficheiro original. Verifique se est\u00e1 em uso.\n");
            DeleteFileW(caminho_temp);
            return 0;
        }
        if (!MoveFileW(caminho_temp, caminho_ebook)) {
            wprintf(L"ERRO: Falha cr\u00edtica ao renomear o ficheiro tempor\u00e1rio.\n");
            return 0;
        }
        wprintf(L"Licen\u00e7a injectada com sucesso!\n");
    } else {
        DeleteFileW(caminho_temp);
    }

    return sucesso;
}