#ifndef DOWNLOADER_H
#define DOWNLOADER_H

#include <wchar.h>

/* Descarrega o ebook. Retorna o caminho completo do ficheiro guardado 
   (deve ser libertado com free() mais tarde) ou NULL em caso de erro. */
wchar_t *descarregar_ebook(const char *url, const char *mime_type, const char *id_licenca, const wchar_t *caminho_lcpl);

#endif /* DOWNLOADER_H */